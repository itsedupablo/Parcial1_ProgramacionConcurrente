package com.edupablo.parcial1.fabrica_galton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FabricaGaltonApplication {

	public static void main(String[] args) {
		SpringApplication.run(FabricaGaltonApplication.class, args);
	}

}
